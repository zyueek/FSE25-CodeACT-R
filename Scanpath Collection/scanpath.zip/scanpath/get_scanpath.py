import tqdm
import pandas as pd
import os
import math


def clean(lst):
    cleaned_list = []
    for i, item in enumerate(lst):
        # Skip NaN values
        if isinstance(item, float) and math.isnan(item):
            continue
        # Add to cleaned list if not adjacent duplicate or NaN
        if not cleaned_list or item != cleaned_list[-1]:
            cleaned_list.append(item)
    return cleaned_list
if __name__ == "__main__":
    f_list = [f for f in os.listdir("tobii_scanpath_distance")]
    columns = ['pid', 'stimuli', 'scanpath']
    df_big = pd.DataFrame(columns=columns)
    for f in f_list:
        columns = ['pid', 'stimuli', 'scanpath']
        df_final = pd.DataFrame(columns=columns)
        name=f.split('_')[2]
        df=pd.read_csv("tobii_scanpath_distance/"+f)
        stimulilsit=list(set(df['stimuli_number'].to_list()))
        for s in stimulilsit:

            df_s=df[df['stimuli_number']==s]
            scanpath=df_s['token'].to_list()

            scanpath='_'.join(clean(scanpath))
#            print(scanpath)
            scanpath1=[]
            for scan in scanpath.split('_'):
                if ',' in str(scan):
                    scan=scan.split(',')[0]
                scanpath1.append(scan)
            scanpath1='_'.join(scanpath1)
#                print(str(s))
#            scanpath = [i.split(',')[0] for i in scanpath.split('_') if ',' in str(i)]

#            scanpath = '_'.join(scanpath)
            df_final.loc[len(df_final.index)]=[name,s,scanpath1]
            df_big.loc[len(df_big.index)]=[name,s,scanpath1]
        out='path_participant/'+f.split('_')[2]+'path.csv'
        df_final.to_csv(out,index=False)
    df_big.to_csv('all_scan_with_repeat.csv',index=False)
#    print(df_final)


