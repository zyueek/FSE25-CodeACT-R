import pandas as pd
import re
import argparse
import random
import os
import warnings
import ast
def min_list(original_list):
  unique_sublists_set = set(tuple(sublist) for sublist in original_list)
  unique_sublists = [list(sublist) for sublist in unique_sublists_set]
  return unique_sublists
def get_evascan(df_simu,indicator):
  scanpath=[]
  linescan=[]
  overscan=[]
  if int(indicator)>=0 or int(indicator < -2):
    for i in range(len(df_simu)):
      simulist=ast.literal_eval(df_simu['minsimu'][i])
      if df_simu['dist'][i]<1:
        for simu in simulist:
          scanpath.append(simu[0])
    return scanpath,i+1
  elif int(indicator)==-1:
#    print('asdasd')
    for i in range(len(df_simu)):
      overlist=ast.literal_eval(df_simu['minranall'][i])
      if df_simu['rand_dist_overall'][i]<1:
        for over in overlist:
          overscan.append(over[0])
#    print(overscan)
    return overscan,i+1
  elif int(indicator)==-2:
    for i in range(len(df_simu)):
      linelist=ast.literal_eval(df_simu['minranline'][i])
      if df_simu['rand_dist_line'][i]<1:      
        for line in linelist:
          linescan.append(line[0])
    return linescan,i+1
def coverage_zero(stim,aug):
  indicator=int(aug)
  if(int(aug)<=0 and int(aug)>=-2):
    aug='0'
#  print(indicator,aug)
  df_e=pd.read_csv("all_scanpath_repeat/sti_"+stim[4:]+"_all.csv")
  pidlist=list(set(df_e['pid'].to_list()))
  evalist=[]
  for pid in pidlist:
    evalist.append(df_e[df_e['pid']==pid]['line'].to_list())
  allscan=min_list(evalist)
  s_list=[s for s in os.listdir('cross_valid_result') if (s.split('_')[0]==stim and s.split("_")[2]=='aug'+aug+'.csv')]
#  print(s_list)
  simuscan=[]
  for s in s_list:
    df_simu=pd.read_csv('cross_valid_result/'+s)
    scanpath,num=get_evascan(df_simu,indicator)
    simunum=len(df_simu)
#    scanpath=[f.split('_') for f in df_simu['minsimu'].to_list()]
    for scan in scanpath:
      simuscan.append(scan)  
  print(num,len(simuscan),simunum)
  balance_ratio=simunum/len(evalist)
  simuscan_min=min_list(simuscan)
#  return len(simuscan)/len(allscan),len(simuscan)/(simunum*len(s_list))*balance_ratio
  return len(simuscan_min)/len(allscan),len(simuscan)/simunum
warnings.filterwarnings("ignore")
parser=argparse.ArgumentParser()
parser.add_argument('--target',required=True)
#parser.add_argument('--seed',required=True)
args=parser.parse_args()
f_list=[f for f in os.listdir(args.target)]
columns=['stim','type','avgdist','bestavg','coverage','cov_expectation']
df_result=pd.DataFrame(columns=columns)
for f in f_list:
  df=pd.read_csv(args.target+"/"+f) 
  stim=df['stim'][0]  
#  seedlist=list(set(df['seed'].to_list()))
  auglist=list(set(df['aug'].to_list()))
  for aug in auglist:
#    print(aug)
    df_aug=df[df['aug']==aug]
    avg=df_aug['avgdist'].to_list()
    best=df_aug['bestdist'].to_list()
#    avg_sem=df_aug['avgdist_sem'].to_list()
#    best_sem=df_aug['bestdist_sem'].to_list()
    avgdist=round(sum(avg)/len(df_aug),3)
    bestavg=round(sum(best)/len(df_aug),3)
#    avgdist_sem=round(sum(avg_sem)/len(df_aug),3)
#    bestavg_sem=round(sum(best_sem)/len(df_aug),3)
    if(aug=='rand_dist_overall'):
      aug=-1
      stype='-1'
      coverage,cov_expectation=coverage_zero(stim,str(aug))
    elif(aug=='rand_dist_line'):
      aug=-2
      stype='-2'
      coverage,cov_expectation=coverage_zero(stim,str(aug))
    elif(aug=='999'):
      stype='path'
    elif(aug=='0'):
      coverage,cov_expectation=coverage_zero(stim,str(aug))
      stype=aug
    else:
      coverage,cov_expectation=coverage_zero(stim,str(aug))
      stype=aug
    coverage=round(coverage,3)
    cov_expectation=round(cov_expectation,3)
    df_result.loc[len(df_result.index)]=[stim,stype,avgdist,bestavg,coverage,cov_expectation]
alltype=list(set(df_result['type'].to_list()))
alltype=[t for t in alltype if -10<=int(t)<=10]
print(alltype)
for t in alltype:
  df_type=df_result[df_result['type']==t]
#  df_type2 = df_result[df_result['type'].apply(lambda x: x.startswith(t) and x != t)]
#  print(df_type2)
#  if(df_type2.empty==False and int(t)!=10 and int(t)!=-10):
#    avgdist = round(df_type2['avgdist'].mean(),3)
#    bestavg = round(df_type2['bestavg'].mean(),3)
#    avgdist_sem = round(df_type2['avgdist_sem'].mean(),3)
#    bestavg_sem = round(df_type2['bestavg_sem'].mean(),3)
#    coverage = round(df_type2['coverage'].mean(),3)
#    cov_exp = round(df_type2['cov_expectation'].mean(),3)
#    print(t+'0',avgdist,bestavg,coverage,cov_exp)
  avgdist = round(df_type['avgdist'].mean(),3)
  bestavg = round(df_type['bestavg'].mean(),3)
#  avgdist_sem = round(df_type['avgdist_sem'].mean(),3)
#  bestavg_sem = round(df_type['bestavg_sem'].mean(),3)
  coverage = round(df_type['coverage'].mean(),3)
  cov_exp = round(df_type['cov_expectation'].mean(),3)
  print(t,avgdist,bestavg,coverage,cov_exp)
df_result.to_csv(args.target+"_report.csv",index=False)
    
      
      
